# Changelog

## 1.0.9
- True Field Name Priority
- Time-based Debounce
- Sex changelog
- pls cache pls
- this is torture omg omlllll
- this is turning into badupdate xbox 360
- culprit had to be debounce itself

## 1.0.8
- How many fixes can we do speedrun?
  (fix x3)

## 1.0.7
- Added some stuff i keep forgoring (im a bad dev lol)
- Updated readme

## 1.0.6
- Dont press esc for binding the menu im NOT fixing that, thats pain.
- if your in global sanctum area it will start if you go somewhere else
- Debugging feature

## 1.0.5
- Odd spam bug? for the third time i hope this debounce system fixes that
- should disable on singleplayer, no need for it on singleplayer
- Added caching the names so it can remember

## 1.0.4
- Odd spam bug? i hope this fixes that 

## 1.0.3
- Added GUI

## 1.0.2
- Spam issue resolved

## 1.0.1
- Erased the reflection stuff since its fully unused

## 1.0.0
- Initial release