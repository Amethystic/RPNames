# AutoMapRoom

## Keep organized with chats by automation | Works through room names to unclutter the chat
To open the menu press the ```F8``` key
```Gurt: yo```