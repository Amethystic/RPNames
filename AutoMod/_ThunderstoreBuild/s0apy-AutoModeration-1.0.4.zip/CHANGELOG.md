# Changelog
## 1.0.4
- characther clone still gay

## 1.0.3
- Fixed and added Hashing

## 1.0.1 - 1.0.2
- Fix cuz character clone is gay n needs to not be that thx
- Changed Readme
- Fixed allowing messages to go through that contain banned words, as long as they also contain an "allowed" word.

## 1.0.0
- Initial release