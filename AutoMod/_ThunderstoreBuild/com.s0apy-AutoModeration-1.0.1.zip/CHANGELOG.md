# Changelog
## 1.0.1
- Fix cuz character clone is gay n needs to not be that thx

## 1.0.0
- Initial release