# AutoMod

## Automods like discord!

For the configuration check your bepinex config folder!