# AutoMod

## Automods like discord!